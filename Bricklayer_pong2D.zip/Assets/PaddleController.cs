using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PaddleController : MonoBehaviour
{

    public float kecepatan;
    public string axis;
    public float batasKiri;
    public float batasKanan;

    private Rigidbody2D rb;
    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
    }

    // Update is called once per frame
    void Update()
    {
        float gerak = Input.GetAxis(axis) * kecepatan * Time.deltaTime;

        float targetX = Mathf.Clamp(rb.position.x + gerak, batasKiri, batasKanan);
        Vector2 targetPos = new Vector2(targetX, rb.position.y);
        rb.MovePosition(targetPos);
    }
}
