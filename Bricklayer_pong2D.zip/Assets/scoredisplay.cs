using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class scoredisplay : MonoBehaviour
{
    public Text currenttextScore;

    public string skor;


    void Start()
    {
        skor = PlayerPrefs.GetString("MyVariable");
        currenttextScore.text = skor.ToString();
    }

    private void Update()
    {
        
    }
}