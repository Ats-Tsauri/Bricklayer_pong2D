using System.Collections;
using System.Collections.Generic;
using UnityEditor.PackageManager.UI;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class BrickHard : MonoBehaviour
{
    private int hits = 0;
    public Material[] materials;
    private Renderer objectRenderer;
    private AudioSource onhit;
    public AudioClip sound;
    public float delay = 0.5f;
    private int wincon=0;

    public Text textScore;


    private void Start()
    {
        // Mendapatkan referensi ke komponen Renderer pada objek ini
        objectRenderer = GetComponent<Renderer>();
        PlayerPrefs.SetString("MyVariable", "0");
        PlayerPrefs.DeleteAll();
        Debug.Log("PlayerPrefs telah direset.");
        Data.score = 0;

        onhit = gameObject.AddComponent<AudioSource>();
        onhit.clip = sound;
    }

    // Ketika objek ini bertabrakan dengan objek lain
    private void OnCollisionEnter2D(Collision2D collision)
    {
        // Periksa apakah objek yang ditabrak memiliki tag "Player"
        if (collision.gameObject.CompareTag("ball"))
        {
            // Tambahkan satu hit
            hits++;
            onhit.Play();

            // Periksa apakah objek telah terkena 3 kali
            if (hits >= 3)
            {
                
                Data.score += 10;
                textScore.text = Data.score.ToString();
                PlayerPrefs.SetString("MyVariable", textScore.text);

                Invoke("DestroyObject", delay);

            }
            else
            {
                // Ubah penampilan objek dengan material yang sesuai
                if (hits - 1 < materials.Length)
                {
                    objectRenderer.material = materials[hits - 1];
                    
                }
            }
        }
    }
    void DestroyObject()
    {
        // Hancurkan objek
        Destroy(gameObject);
        wincon++;
        Debug.Log("Stack Count: " + wincon);

        if (wincon >= 10)
        {
            SceneManager.LoadScene(7);
        }
    }
}
