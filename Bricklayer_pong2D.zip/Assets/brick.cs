using System.Collections;
using System.Collections.Generic;
using Unity.Collections.LowLevel.Unsafe;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using Unity.VisualScripting;


public class brick : MonoBehaviour
{
    //private int hits = 0;
    public Material[] materials;
    private Renderer objectRenderer;
    private AudioSource onhit;
    public AudioClip sound;
    public float delay = 0.5f;
    private int count = 0;
    

    public Text textScore;

    private void Start()
    {
        // Mendapatkan referensi ke komponen Renderer pada objek ini
        objectRenderer = GetComponent<Renderer>();
        PlayerPrefs.SetString("currentScore", "0");
        PlayerPrefs.SetString("MyVariable", "0");
        Data.score =0;

        onhit = gameObject.AddComponent<AudioSource>();
        onhit.clip = sound;
    }

    // Ketika objek ini bertabrakan dengan objek lain
    private void OnCollisionEnter2D(Collision2D collision)
    {
        // Periksa apakah objek yang ditabrak memiliki tag "Player"
        if (collision.gameObject.CompareTag("ball"))
        {
            // Tambahkan satu hit
            //hits;

            // Periksa apakah objek telah terkena 3 kali
            //if (hits >= 3)
            //{
                Data.score += 10;
                textScore.text = Data.score.ToString();
                PlayerPrefs.SetString("MyVariable",textScore.text);
                Invoke("DestroyObject", delay);
                onhit.Play();
                
            //}
            //else
            //{
                // Ubah penampilan objek dengan material yang sesuai
            //    if (hits - 1 < materials.Length)
            //    {
            //        objectRenderer.material = materials[hits - 1];
            //    }
            //}
        }
    }
    void DestroyObject()
    {
        // Hancurkan objek
       
        count++;
        Debug.Log("Stack Count: " + count);

        if (count >= 10)
        {
            Winning();
        }
        Destroy(gameObject);
        
    }
    void Winning()
    {
        SceneManager.LoadScene(6);
    }
}
