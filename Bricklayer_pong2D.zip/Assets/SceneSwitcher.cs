using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;


public class SceneSwitcher : MonoBehaviour
{
    public void ChoosingDifficulty()
    {
        SceneManager.LoadScene(1);
        PlayerPrefs.SetString("MyVariable", "0");
        PlayerPrefs.DeleteAll();
        Debug.Log("PlayerPrefs telah direset.");
    }
    public void NormalStages()
    {
        SceneManager.LoadScene(2);
        PlayerPrefs.SetString("MyVariable", "0");
        PlayerPrefs.DeleteAll();
        Debug.Log("PlayerPrefs telah direset.");
    }
    public void HardStages()
    {
        SceneManager.LoadScene(3);
        PlayerPrefs.SetString("MyVariable", "0");
        PlayerPrefs.DeleteAll();
        Debug.Log("PlayerPrefs telah direset.");

    }
    public void keluar()
    {
        SceneManager.LoadScene(0);
        PlayerPrefs.SetString("MyVariable", "0");
        PlayerPrefs.DeleteAll();
        Debug.Log("PlayerPrefs telah direset.");
    }
    public void GameOver()
    {
        SceneManager.LoadScene(4);

    }
    public void GameOverhard()
    {
        SceneManager.LoadScene(5);

    }
    public void Exit() 
    {
        Application.Quit();
        Debug.Log("keluar aplikkasi");
    }
}

