using UnityEngine;
using UnityEngine.SceneManagement;
using System.Collections.Generic;

public class SceneBackManager : MonoBehaviour
{
    private List<string> sceneHistory = new List<string>();

    public void GoBackToPreviousScene()
    {
        if (sceneHistory.Count > 1)
        {
            string previousSceneName = sceneHistory[sceneHistory.Count - 2];
            SceneManager.LoadScene(previousSceneName);
        }
        else
        {
            Debug.LogWarning("Tidak ada scene sebelumnya.");
        }
    }

    private void Start()
    {
        // Simpan nama scene saat ini ke dalam daftar sejarah.
        string currentSceneName = SceneManager.GetActiveScene().name;
        sceneHistory.Add(currentSceneName);
    }

    public void LoadScene(string sceneName)
    {
        SceneManager.LoadScene(sceneName);

        // Simpan nama scene saat ini ke dalam daftar sejarah.
        sceneHistory.Add(sceneName);
    }
}
