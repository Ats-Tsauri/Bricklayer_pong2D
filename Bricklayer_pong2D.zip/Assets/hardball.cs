using System;
using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.SceneManagement;

public class hardball : MonoBehaviour
{
    // Start is called before the first frame update

    public int force;
    public Rigidbody2D rigid;
    public AudioClip sound;
    private AudioSource death;
    public float delay = 0.5f;


    void Start()
    {
        rigid = GetComponent<Rigidbody2D>();
        Vector2 arah = new Vector2(0, 2).normalized;
        rigid.AddForce(arah * force);

        PlayerPrefs.DeleteAll();
        Debug.Log("PlayerPrefs telah direset.");

        death = gameObject.AddComponent<AudioSource>();
        death.clip = sound;
    }

    // Update is called once per frame
    void Update()
    {

    }


    private void OnCollisionEnter2D(Collision2D coll)
    {
        if (coll.gameObject.name == "Redline")
        {
            death.Play();
            Invoke("DestroyObject", delay);
            Invoke("GantiScene", delay);
            //ResetBall();
            //Vector2 arah = new Vector2(0, 2).normalized;
            //rigid.AddForce(arah * force);
        }

        if (coll.gameObject.name == "Paddle")
        {
            float sudut = (transform.position.x - coll.transform.position.x) * 5f;
            Vector2 arah = new Vector2(sudut, rigid.velocity.y).normalized;
            rigid.velocity = new Vector2(0, 0);
            rigid.AddForce(arah * force * 2);
        }
    }
    void ResetBall()
    {
        transform.localPosition = new Vector2(0, 0);
        rigid.velocity = new Vector2(0, 0);
    }
    void DestroyObject()
    {
        // Hancurkan objek
        Destroy(gameObject);
    }
    void GantiScene()
    {
        SceneManager.LoadScene(5);
    }
}
